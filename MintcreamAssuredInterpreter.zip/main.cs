using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine(" Skriv ditt fornamn: ");
    string fornamn = Console.ReadLine();
    Console.WriteLine(" skriv ditt efternamn: ");
    string efternamn = Console.ReadLine();
    Console.WriteLine(" skriv din older: ");
    string older = Console.ReadLine();
    Console.WriteLine("are you sad: ");
    string sad = Console.ReadLine();
    Console.WriteLine("too bad for you");


    Console.WriteLine(fornamn +" "+ efternamn +" "+ older);

    Console.WriteLine("start over: ");
    string again = Console.ReadLine();
    
  }
}